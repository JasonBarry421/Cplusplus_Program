#pragma once
#ifndef Creating_Frequency_Data_h
#define Creating_Frequency_Data_h

#include <iostream>
#include<cstring>
#include<vector>			//allows use of vectors
#include<algorithm>		//Allows use of .find() function
#include<map>			//Allows use of maps
#include<string>			//Allows use of strings
#include<fstream>
using namespace std;

class FrequencyTable {
	public:
		//Displays Menu
		void DisplayMenu();

		//Gets Item Frequency
		void GetItemFrequency(vector<string>& table);

		//Gets All Items Frequency
		void GetAllItemsFrequency(vector<string>& table);

		//Gets All Items as a Histogram
		void GetAsHistogram(vector<string>& table);
		
		//Allows Creation of New Vector Table
		vector<string> newTable;

		//Creates Iterator for use in .find()
		vector<string>::iterator iter;

		//Creates Map to include items
		map <string, int> itemFreq;

	private:
		//Declares Private Variables
		char currLetter;
		string itemName;
		string currItem;
		string currString;
		int wordFreq = 0;
		int i = 0;
		int size = 0;
		ofstream outFS;
		ifstream inFS;
};
#endif