#pragma once
#ifndef Input_Initial_File_and_Menu_h
#define Input_Initial_File_and_Menu_h

#include<iostream>
#include "Creating_Frequency_Data.h"
#include<fstream>
#include<string>
#include<vector>

using namespace std;

class UserInput {
	public:
		int FileAndMenu();
	private:
		//Declares Class Object
		FrequencyTable userTable;

		//Declares Vector
		vector<string> frequencyTable;

		//Declares Variables
		string currItem;
		int choice;

		//Declares Input File Stream (used for reading stuff from File)
		ifstream inFS;
};

#endif