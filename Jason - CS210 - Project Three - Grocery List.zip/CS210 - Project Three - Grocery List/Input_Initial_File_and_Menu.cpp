#include "Input_Initial_File_and_Menu.h"


int UserInput::FileAndMenu() {
	//Opens Input File
	inFS.open("Project_Three_Grocery_List_Text_File.txt");

	//Outputs if Input File Doesn't Open
	if (!inFS.is_open()) {
		cout << "Could not open Project_Three_Grocery_List_Text_File.txt" << endl;
	}


	//Creates Frequency Table Vector
	while (!inFS.eof()) {
		inFS >> currItem;
		frequencyTable.push_back(currItem);
	}

	//Closes Input and Output Files
	inFS.close();

	//Displays Menu
	userTable.DisplayMenu();

	//Gets User Choice
	cin >> choice;

	//While user doesn't end program
	while (choice != 4 || cin.fail()) {
		//Converts choice to string to ensure user only entered one number
		string strChoice = to_string(choice);

		//Ensures user entered only one number
		if(strChoice.length() == 1){
			//Ends program if user doesn't enter an integer
			if (cin.fail()) {
				return 0;
			}
			switch (choice) {
				//Gets Item Frequency
				case 1: {
					cout << endl;
					userTable.GetItemFrequency(frequencyTable);
					cout << endl;
					userTable.DisplayMenu();
					cin >> choice;
					break;
				}

				//Gets All Items Frequency
				case 2: {
					cout << endl;
					userTable.GetAllItemsFrequency(frequencyTable);
					cout << endl;
					userTable.DisplayMenu();
					cin >> choice;
					break;
				}

				//Gets All Items as a Histogram
				case 3: {
					cout << endl;
					userTable.GetAsHistogram(frequencyTable);
					cout << endl;
					userTable.DisplayMenu();
					cin >> choice;
					break;
				}

				//Quits Program
				case 4:
					return 0;

				//Asks user to Input Something Else
				default: {
					cout << "\nPlease choose a number between 1 and 4.\n\n";
					userTable.DisplayMenu();
					cin >> choice;
					break;
				}
			}
		}
		//Executes if user enters more than one integer
		else {
			cout << "You must enter only one integer! ";
			cin >> choice;

		}
	}
}

