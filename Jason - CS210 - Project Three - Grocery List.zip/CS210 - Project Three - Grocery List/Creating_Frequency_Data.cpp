#include "Creating_Frequency_Data.h"

//Displays Menu
void FrequencyTable::DisplayMenu() {
	cout << "*******************************************************\n";
	cout << "*               Corner Grocery Item List              *\n";
	cout << "*******************************************************\n";
	cout << "* 1: Get Frequency of Specific Item                   *\n";
	cout << "* 2: Get Frequency of All Items                       *\n";
	cout << "* 3: Get Frequency of All Items as a Histogram        *\n";
	cout << "* 4: Exit Program                                     *\n";
	cout << "*******************************************************";
	cout << "\n\n";
}

//Gets Item Frequency
void FrequencyTable::GetItemFrequency(vector<string>& table) {
	//Asks for item from user and stores answer in itemName
	cout << "What item are you looking for? ";
	
	//Allows full line Input
	cin.ignore();

	/*
		* Gets entire line
			* useful if user inputs more than one
			  word which would otherwise lead to 
			  an infinite loop
	*/
	getline(cin, itemName);

	size = table.size() - 1;

	//Makes itemName all lower case to fix case-sensative issue
	for (int i = 0; i < itemName.size(); ++i) {
		itemName.at(i) = tolower(itemName.at(i));
	}

	//Iterates through Vector
	for (int i = 0; i < (size); ++i) {


		currItem = table.at(i);

		//Makes currItem all lower case to fix case-sensative issue
		for (int i = 0; i < currItem.size(); ++i) {
			currItem.at(i) = tolower(currItem.at(i));
		}

		//Adds 1 to wordFreq whenever itemName appears in Vector
		if (currItem == itemName) {
			wordFreq += 1;
		}
	}

	//Displays message if item is not in list
	if (wordFreq == 0) {
		cout << "That item doesn't appear in the list.\n";
	}
	//Otherwise Displays wordFrq
	else {
		//Makes first letter uppercase again
		for (int i = 0; i < itemName.size(); ++i) {
			if (i == 0) {
				itemName.at(i) = toupper(itemName.at(i));
			}
		}
		cout << itemName << " appears " << wordFreq << " times.\n";
		wordFreq = 0;
	}
}

//Gets All Items Frequency
void FrequencyTable::GetAllItemsFrequency(vector<string>& table) {
	//Opens Output File
	outFS.open("frequency.dat.txt");


	//Outputs if Output File Doesn't Open
	if (!outFS.is_open()) {
		cout << "Could not open frequency.dat" << endl;
	}
	
	
	size = table.size() - 1;

	//Iterates through Vector
	for (int i = 0; i < size; ++i) {
		//Assigns item in vector.at(i) to itemName
		itemName = table.at(i);

		//Iterates through Vector
		for (int i = 0; i < size; ++i) {
			//Adds 1 to wordFreq whenever itemName appears in Vector
			if (itemName == table.at(i)){
				wordFreq += 1;
			}
		}
		
		//Finds if itemName is in newTable vector
		iter = find(newTable.begin(), newTable.end(), itemName);

		/*
			*If itemName is NOT in newTable vector
				* Adds itemName to newTable vector
				* Creates and Displays Map
		*/
		
		if (iter == newTable.end()) {
			newTable.push_back(itemName);
			itemFreq.emplace(itemName, wordFreq);

			//Adds to Output File
			outFS << itemName << " " << itemFreq.at(itemName) << endl;

			//Displays Information to User
			cout << itemName << " " << itemFreq.at(itemName) << endl;
		}
		//Resets wordFreq
		wordFreq = 0;
	}
	//Closes Output File
	outFS.close();
}

void FrequencyTable::GetAsHistogram(vector<string>& table) {
	//Creates new Class Object
	FrequencyTable histogramTable;

	//Displays Regular Frequency List
	cout << "\n\n\n*****************************************\n";
	cout << "* Base Frequency List....               *\n";
	cout << "*****************************************\n\n";

	/* Calls GetAllItemsFrequency
		 all information is added to Txt File
			and
		outputs all information
	*/
	histogramTable.GetAllItemsFrequency(table);

	//Declares Input File Stream (used for reading stuff from File)
	ifstream inFS;

	//Opens Input File
	inFS.open("frequency.dat.txt");

	//Outputs if Input File Doesn't Open
	if (!inFS.is_open()) {
		cout << "Could not open frequency.dat.txt" << endl;
	}

	//Displays Begining of Histogram
	cout << "\n\n\n*****************************************\n";
	cout << "* Beginning Histogram....               *\n";
	cout << "*****************************************\n\n";

	//Creates Frequency Table Vector
	while (!inFS.eof()) {
		inFS >> itemName >> wordFreq;
		if (!inFS.fail()) {
			cout << itemName << " ";
			for (int i = 0; i < wordFreq; ++i) {
				cout << '*';
			}
			cout << endl;
		}
	}
}