#include<iostream>
#include "Input_Initial_File_and_Menu.h"
using namespace std;

/*
   Jason Barry
   Project Three - Grocery List
   October 14, 2023
*/

//To Maximize Code Reuseability, I wanted main.cpp to be as short as possible 
int main() {
	UserInput menu;
	menu.FileAndMenu();
	return 0;
}